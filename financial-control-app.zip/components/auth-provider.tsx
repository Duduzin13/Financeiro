"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import type { User, Session } from "@supabase/supabase-js"
import { initSupabase } from "@/lib/supabase"

type AuthContextType = {
  user: User | null
  session: Session | null
  loading: boolean
  error: string | null
}

const AuthContext = createContext<AuthContextType>({ user: null, session: null, loading: true, error: null })

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function initializeAuth() {
      try {
        console.log("Initializing Supabase in AuthProvider")
        const supabase = initSupabase()

        console.log("Fetching initial session")
        const {
          data: { session },
        } = await supabase.auth.getSession()
        setSession(session)
        setUser(session?.user ?? null)

        console.log("Setting up auth state change listener")
        const {
          data: { subscription },
        } = supabase.auth.onAuthStateChange((_event, session) => {
          setSession(session)
          setUser(session?.user ?? null)
        })

        return () => {
          subscription.unsubscribe()
        }
      } catch (e) {
        console.error("Error in AuthProvider:", e)
        setError(e instanceof Error ? e.message : "An unknown error occurred")
      } finally {
        setLoading(false)
      }
    }

    initializeAuth()
  }, [])

  return <AuthContext.Provider value={{ user, session, loading, error }}>{children}</AuthContext.Provider>
}

