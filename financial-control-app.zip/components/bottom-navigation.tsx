"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, PieChart, TrendingUp, Wallet } from "lucide-react"

export function BottomNavigation() {
  const pathname = usePathname()

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border">
      <div className="max-w-md mx-auto flex justify-around">
        <NavItem href="/dashboard" icon={<Home size={20} />} label="Início" isActive={pathname === "/dashboard"} />
        <NavItem href="/income" icon={<TrendingUp size={20} />} label="Entradas" isActive={pathname === "/income"} />
        <NavItem href="/expenses" icon={<Wallet size={20} />} label="Despesas" isActive={pathname === "/expenses"} />
        <NavItem href="/reports" icon={<PieChart size={20} />} label="Relatórios" isActive={pathname === "/reports"} />
      </div>
    </div>
  )
}

function NavItem({
  href,
  icon,
  label,
  isActive,
}: {
  href: string
  icon: React.ReactNode
  label: string
  isActive: boolean
}) {
  return (
    <Link
      href={href}
      className={`flex flex-col items-center py-2 px-4 ${isActive ? "text-primary" : "text-muted-foreground"}`}
    >
      {icon}
      <span className="text-xs mt-1">{label}</span>
    </Link>
  )
}

