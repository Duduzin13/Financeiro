-- Create tables for the financial control app

-- Enable RLS (Row Level Security)
alter table public.profiles enable row level security;
alter table public.incomes enable row level security;
alter table public.expenses enable row level security;

-- Create a table for user profiles
create table public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  username text unique,
  full_name text,
  avatar_url text,
  website text,
  
  constraint username_length check (char_length(username) >= 3)
);

-- Create a table for incomes
create table public.incomes (
  id uuid default uuid_generate_v4() primary key not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  description text not null,
  amount decimal(10,2) not null
);

-- Create a table for expenses
create table public.expenses (
  id uuid default uuid_generate_v4() primary key not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  description text not null,
  amount decimal(10,2) not null,
  category text not null,
  expense_category text not null
);

-- Set up Row Level Security (RLS)
-- Profiles: Users can only view and update their own profile
create policy "Users can view their own profile" on public.profiles
  for select using (auth.uid() = id);

create policy "Users can update their own profile" on public.profiles
  for update using (auth.uid() = id);

-- Incomes: Users can only CRUD their own incomes
create policy "Users can view their own incomes" on public.incomes
  for select using (auth.uid() = user_id);

create policy "Users can create their own incomes" on public.incomes
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own incomes" on public.incomes
  for update using (auth.uid() = user_id);

create policy "Users can delete their own incomes" on public.incomes
  for delete using (auth.uid() = user_id);

-- Expenses: Users can only CRUD their own expenses
create policy "Users can view their own expenses" on public.expenses
  for select using (auth.uid() = user_id);

create policy "Users can create their own expenses" on public.expenses
  for insert with check (auth.uid() = user_id);

create policy "Users can update their own expenses" on public.expenses
  for update using (auth.uid() = user_id);

create policy "Users can delete their own expenses" on public.expenses
  for delete using (auth.uid() = user_id);

-- Create a function to handle new user signups
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url');
  return new;
end;
$$ language plpgsql security definer;

-- Trigger the function every time a user is created
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

