# Financial Control App

A Next.js application for tracking personal finances, using Supabase for authentication and database.

## Setup

1. Create a Supabase project at [supabase.com](https://supabase.com)
2. Run the SQL migrations in `supabase/migrations` in your Supabase SQL editor
3. Get your Supabase URL and anon key from the project settings
4. Create a `.env.local` file with the following variables:

