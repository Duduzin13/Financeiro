package com.example.financialcontrol

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class FinancialControlApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Firebase with the configuration from google-services.json
        FirebaseApp.initializeApp(this)
    }
}

