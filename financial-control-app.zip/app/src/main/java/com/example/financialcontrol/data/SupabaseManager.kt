package com.example.financialcontrol.data

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.postgrest.Postgrest

object SupabaseManager {
    private const val SUPABASE_URL = "https://lfektiroskyzruqjvlhw.supabase.co"
    private const val SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxmZWt0aXJvc2t5enJ1cWp2bGh3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDExNzkyNjMsImV4cCI6MjA1Njc1NTI2M30.sTuqp2PKK9bnLwhUib2Knof3cWQb2XtysozN_vv1x_E"

    val client = createSupabaseClient(
        supabaseUrl = SUPABASE_URL,
        supabaseKey = SUPABASE_KEY
    ) {
        install(GoTrue)
        install(Postgrest)
    }

    val auth get() = client.gotrue
    val db get() = client.postgrest
}

