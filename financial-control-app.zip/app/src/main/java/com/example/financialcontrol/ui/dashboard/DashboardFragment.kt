package com.example.financialcontrol.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.financialcontrol.data.SupabaseManager
import com.example.financialcontrol.databinding.FragmentDashboardBinding
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    @Serializable
    data class FinancialEntry(
        val id: Int,
        val description: String,
        val amount: Double,
        val type: String // "income" or "expense"
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        lifecycleScope.launch {
            try {
                val result = SupabaseManager.db
                    .from("financial_entries")
                    .select()
                    .execute()
                
                val entries = result.decodeList<FinancialEntry>()
                
                val totalIncome = entries.filter { it.type == "income" }.sumOf { it.amount }
                val totalExpenses = entries.filter { it.type == "expense" }.sumOf { it.amount }
                val balance = totalIncome - totalExpenses

                binding.textDashboard.text = """
                    Total Income: $${String.format("%.2f", totalIncome)}
                    Total Expenses: $${String.format("%.2f", totalExpenses)}
                    Balance: $${String.format("%.2f", balance)}
                """.trimIndent()
            } catch (e: Exception) {
                binding.textDashboard.text = "Error: ${e.message}"
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

