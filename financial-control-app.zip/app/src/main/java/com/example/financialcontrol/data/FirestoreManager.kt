package com.example.financialcontrol.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class FirestoreManager {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    suspend fun addIncome(description: String, amount: Double) {
        val userId = auth.currentUser?.uid ?: return
        val income = hashMapOf(
            "description" to description,
            "amount" to amount
        )
        db.collection("users").document(userId).collection("incomes").add(income).await()
    }

    suspend fun addExpense(description: String, amount: Double, category: String, isEssential: Boolean) {
        val userId = auth.currentUser?.uid ?: return
        val expense = hashMapOf(
            "description" to description,
            "amount" to amount,
            "category" to category,
            "isEssential" to isEssential
        )
        db.collection("users").document(userId).collection("expenses").add(expense).await()
    }

    suspend fun getIncomes(): List<Income> {
        val userId = auth.currentUser?.uid ?: return emptyList()
        val snapshot = db.collection("users").document(userId).collection("incomes").get().await()
        return snapshot.documents.mapNotNull { doc ->
            doc.toObject(Income::class.java)?.copy(id = doc.id)
        }
    }

    suspend fun getExpenses(): List<Expense> {
        val userId = auth.currentUser?.uid ?: return emptyList()
        val snapshot = db.collection("users").document(userId).collection("expenses").get().await()
        return snapshot.documents.mapNotNull { doc ->
            doc.toObject(Expense::class.java)?.copy(id = doc.id)
        }
    }
}

data class Income(
    val id: String = "",
    val description: String = "",
    val amount: Double = 0.0
)

data class Expense(
    val id: String = "",
    val description: String = "",
    val amount: Double = 0.0,
    val category: String = "",
    val isEssential: Boolean = false
)

