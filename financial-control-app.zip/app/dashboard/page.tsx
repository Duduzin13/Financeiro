"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDown, ArrowUp, DollarSign } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import {
  formatCurrency,
  calculateTotalIncome,
  calculateTotalExpenses,
  calculateBalance,
  calculateEmergencyFund,
  type Income,
  type Expense,
  getIncomes,
  getExpenses,
} from "@/lib/data"

export default function Dashboard() {
  const [incomes, setIncomes] = useState<Income[]>([])
  const [essentialExpenses, setEssentialExpenses] = useState<Expense[]>([])
  const [nonEssentialExpenses, setNonEssentialExpenses] = useState<Expense[]>([])
  const [dataError, setDataError] = useState<string | null>(null)
  const { user, loading, error } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user && !error) {
      router.push("/login")
    }
  }, [user, loading, error, router])

  useEffect(() => {
    if (user) {
      const fetchData = async () => {
        try {
          const fetchedIncomes = await getIncomes(user.id)
          setIncomes(fetchedIncomes)

          const fetchedExpenses = await getExpenses(user.id)
          setEssentialExpenses(fetchedExpenses.filter((expense) => expense.category === "essential"))
          setNonEssentialExpenses(fetchedExpenses.filter((expense) => expense.category === "non-essential"))
        } catch (error) {
          console.error("Error fetching data:", error)
          setDataError(error instanceof Error ? error.message : "An error occurred while fetching data")
        }
      }

      fetchData()
    }
  }, [user])

  if (loading) {
    return <div>Loading...</div>
  }

  if (error) {
    return <div>Authentication Error: {error}</div>
  }

  if (dataError) {
    return <div>Data Error: {dataError}</div>
  }

  if (!user) {
    return null
  }

  const totalIncome = calculateTotalIncome(incomes)
  const totalEssentialExpenses = calculateTotalExpenses(essentialExpenses)
  const totalNonEssentialExpenses = calculateTotalExpenses(nonEssentialExpenses)
  const totalExpenses = totalEssentialExpenses + totalNonEssentialExpenses
  const balance = calculateBalance(incomes, [...essentialExpenses, ...nonEssentialExpenses])
  const emergencyFund = calculateEmergencyFund([...essentialExpenses, ...nonEssentialExpenses])

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Controle Financeiro</h1>
      <p className="text-sm text-muted-foreground">Atualizado em {new Date().toLocaleDateString("pt-BR")}</p>

      <div className="grid grid-cols-1 gap-4">
        <Card className={`${balance >= 0 ? "bg-green-50" : "bg-red-50"}`}>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Saldo Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <DollarSign className={`mr-2 ${balance >= 0 ? "text-green-500" : "text-red-500"}`} />
              <span className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                {formatCurrency(balance)}
              </span>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Entradas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <ArrowUp className="mr-2 text-green-500" />
                <span className="text-xl font-bold text-green-600">{formatCurrency(totalIncome)}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <ArrowDown className="mr-2 text-red-500" />
                <span className="text-xl font-bold text-red-600">{formatCurrency(totalExpenses)}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Despesas por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Essenciais</span>
                <span className="font-medium">{formatCurrency(totalEssentialExpenses)}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-blue-600 h-2.5 rounded-full"
                  style={{ width: `${(totalEssentialExpenses / totalExpenses) * 100}%` }}
                ></div>
              </div>

              <div className="flex justify-between">
                <span>Não Essenciais</span>
                <span className="font-medium">{formatCurrency(totalNonEssentialExpenses)}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-purple-600 h-2.5 rounded-full"
                  style={{ width: `${(totalNonEssentialExpenses / totalExpenses) * 100}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Reserva de Emergência</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Valor ideal (6 meses de despesas)</p>
              <p className="text-xl font-bold">{formatCurrency(emergencyFund)}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

