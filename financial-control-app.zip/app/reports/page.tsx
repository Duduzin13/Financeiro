"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  initialIncomes,
  initialEssentialExpenses,
  initialNonEssentialExpenses,
  formatCurrency,
  calculateTotalIncome,
  calculateTotalExpenses,
  calculateBalance,
  calculateEmergencyFund,
  type Income,
  type Expense,
} from "@/lib/data"

export default function ReportsPage() {
  const [incomes, setIncomes] = useState<Income[]>([])
  const [essentialExpenses, setEssentialExpenses] = useState<Expense[]>([])
  const [nonEssentialExpenses, setNonEssentialExpenses] = useState<Expense[]>([])

  useEffect(() => {
    // Load data from localStorage or use initial data
    const savedIncomes = localStorage.getItem("incomes")
    const savedEssentialExpenses = localStorage.getItem("essentialExpenses")
    const savedNonEssentialExpenses = localStorage.getItem("nonEssentialExpenses")

    setIncomes(savedIncomes ? JSON.parse(savedIncomes) : initialIncomes)
    setEssentialExpenses(savedEssentialExpenses ? JSON.parse(savedEssentialExpenses) : initialEssentialExpenses)
    setNonEssentialExpenses(
      savedNonEssentialExpenses ? JSON.parse(savedNonEssentialExpenses) : initialNonEssentialExpenses,
    )
  }, [])

  const totalIncome = calculateTotalIncome(incomes)
  const totalEssentialExpenses = calculateTotalExpenses(essentialExpenses)
  const totalNonEssentialExpenses = calculateTotalExpenses(nonEssentialExpenses)
  const totalExpenses = totalEssentialExpenses + totalNonEssentialExpenses
  const balance = calculateBalance(incomes, [...essentialExpenses, ...nonEssentialExpenses])
  const emergencyFund = calculateEmergencyFund([...essentialExpenses, ...nonEssentialExpenses])

  // Calculate percentages
  const essentialPercentage = totalIncome > 0 ? (totalEssentialExpenses / totalIncome) * 100 : 0
  const nonEssentialPercentage = totalIncome > 0 ? (totalNonEssentialExpenses / totalIncome) * 100 : 0
  const savingsPercentage = totalIncome > 0 ? (balance > 0 ? balance / totalIncome : 0) * 100 : 0

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Relatórios</h1>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Resumo Financeiro</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between">
              <span>Total de Entradas</span>
              <span className="font-bold text-green-600">{formatCurrency(totalIncome)}</span>
            </div>
            <div className="flex justify-between">
              <span>Total de Despesas</span>
              <span className="font-bold text-red-600">{formatCurrency(totalExpenses)}</span>
            </div>
            <div className="border-t pt-2 flex justify-between">
              <span>Saldo</span>
              <span className={`font-bold ${balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                {formatCurrency(balance)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Distribuição de Gastos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span>Essenciais</span>
                <span>{essentialPercentage.toFixed(1)}% da renda</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-blue-600 h-2.5 rounded-full"
                  style={{ width: `${Math.min(essentialPercentage, 100)}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span>Não Essenciais</span>
                <span>{nonEssentialPercentage.toFixed(1)}% da renda</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-purple-600 h-2.5 rounded-full"
                  style={{ width: `${Math.min(nonEssentialPercentage, 100)}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span>Economia/Investimentos</span>
                <span>{savingsPercentage.toFixed(1)}% da renda</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-green-600 h-2.5 rounded-full"
                  style={{ width: `${Math.min(savingsPercentage, 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Reserva de Emergência</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Valor ideal (6 meses de despesas)</p>
            <p className="text-xl font-bold">{formatCurrency(emergencyFund)}</p>
            {balance < 0 && (
              <p className="text-sm text-red-500 mt-2">
                Atenção: Seu saldo mensal está negativo. Considere revisar seus gastos para começar a construir sua
                reserva de emergência.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Dicas Financeiras</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 list-disc pl-5">
            <li>Tente manter suas despesas essenciais abaixo de 50% da sua renda</li>
            <li>Limite gastos não essenciais a 30% da sua renda</li>
            <li>Procure economizar pelo menos 20% da sua renda mensalmente</li>
            <li>Construa uma reserva de emergência equivalente a 3-6 meses de despesas</li>
            <li>Revise seus gastos regularmente e identifique oportunidades de economia</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

