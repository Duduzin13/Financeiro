"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Plus, Pencil, Trash2 } from "lucide-react"
import { initialIncomes, formatCurrency, calculateTotalIncome, type Income } from "@/lib/data"

export default function IncomePage() {
  const [incomes, setIncomes] = useState<Income[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingIncome, setEditingIncome] = useState<Income | null>(null)
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState("")

  useEffect(() => {
    // Load data from localStorage or use initial data
    const savedIncomes = localStorage.getItem("incomes")
    setIncomes(savedIncomes ? JSON.parse(savedIncomes) : initialIncomes)
  }, [])

  useEffect(() => {
    // Save to localStorage whenever incomes change
    localStorage.setItem("incomes", JSON.stringify(incomes))
  }, [incomes])

  const handleOpenDialog = (income?: Income) => {
    if (income) {
      setEditingIncome(income)
      setDescription(income.description)
      setAmount(String(income.amount))
    } else {
      setEditingIncome(null)
      setDescription("")
      setAmount("")
    }
    setIsDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setEditingIncome(null)
    setDescription("")
    setAmount("")
  }

  const handleSaveIncome = () => {
    if (!description || !amount) return

    const newIncome: Income = {
      id: editingIncome ? editingIncome.id : Date.now().toString(),
      description,
      amount: Number.parseFloat(amount),
    }

    if (editingIncome) {
      setIncomes(incomes.map((income) => (income.id === editingIncome.id ? newIncome : income)))
    } else {
      setIncomes([...incomes, newIncome])
    }

    handleCloseDialog()
  }

  const handleDeleteIncome = (id: string) => {
    setIncomes(incomes.filter((income) => income.id !== id))
  }

  const totalIncome = calculateTotalIncome(incomes)

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Entradas</h1>
        <Button onClick={() => handleOpenDialog()} size="sm">
          <Plus className="mr-2 h-4 w-4" /> Adicionar
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Total de Entradas</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {incomes.map((income) => (
          <Card key={income.id}>
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">{income.description}</p>
                  <p className="text-lg font-bold text-green-600">{formatCurrency(income.amount)}</p>
                </div>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(income)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDeleteIncome(income.id)}>
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingIncome ? "Editar Entrada" : "Nova Entrada"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium">
                Descrição
              </label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Salário"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="amount" className="text-sm font-medium">
                Valor (R$)
              </label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                step="0.01"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancelar
            </Button>
            <Button onClick={handleSaveIncome}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

