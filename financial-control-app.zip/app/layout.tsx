import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { AuthProvider } from "@/components/auth-provider"
import { ErrorDisplay } from "@/components/ErrorDisplay"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Financial Control App",
  description: "Track your income and expenses",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <AuthProvider>
          {({ error }) => {
            if (error) {
              return <ErrorDisplay error={error} />
            }
            return (
              <div className="flex flex-col min-h-screen max-w-md mx-auto">
                <main className="flex-1 pb-16">{children}</main>
              </div>
            )
          }}
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'