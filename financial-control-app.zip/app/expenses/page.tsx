"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Pencil, Trash2 } from "lucide-react"
import {
  initialEssentialExpenses,
  initialNonEssentialExpenses,
  formatCurrency,
  calculateTotalExpenses,
  type Expense,
  type ExpenseCategory,
  expenseCategories,
} from "@/lib/data"

export default function ExpensesPage() {
  const [essentialExpenses, setEssentialExpenses] = useState<Expense[]>([])
  const [nonEssentialExpenses, setNonEssentialExpenses] = useState<Expense[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState("")
  const [category, setCategory] = useState<"essential" | "non-essential">("essential")
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>("Alimentação")
  const [activeTab, setActiveTab] = useState("essential")

  useEffect(() => {
    // Load data from localStorage or use initial data
    const savedEssentialExpenses = localStorage.getItem("essentialExpenses")
    const savedNonEssentialExpenses = localStorage.getItem("nonEssentialExpenses")

    setEssentialExpenses(savedEssentialExpenses ? JSON.parse(savedEssentialExpenses) : initialEssentialExpenses)
    setNonEssentialExpenses(
      savedNonEssentialExpenses ? JSON.parse(savedNonEssentialExpenses) : initialNonEssentialExpenses,
    )
  }, [])

  useEffect(() => {
    // Save to localStorage whenever expenses change
    localStorage.setItem("essentialExpenses", JSON.stringify(essentialExpenses))
    localStorage.setItem("nonEssentialExpenses", JSON.stringify(nonEssentialExpenses))
  }, [essentialExpenses, nonEssentialExpenses])

  const handleOpenDialog = (expense?: Expense) => {
    if (expense) {
      setEditingExpense(expense)
      setDescription(expense.description)
      setAmount(String(expense.amount))
      setCategory(expense.category)
      setExpenseCategory(expense.expenseCategory)
    } else {
      setEditingExpense(null)
      setDescription("")
      setAmount("")
      setCategory(activeTab as "essential" | "non-essential")
      setExpenseCategory("Alimentação")
    }
    setIsDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setEditingExpense(null)
    setDescription("")
    setAmount("")
  }

  const handleSaveExpense = () => {
    if (!description || !amount) return

    const newExpense: Expense = {
      id: editingExpense ? editingExpense.id : Date.now().toString(),
      description,
      amount: Number.parseFloat(amount),
      category,
      expenseCategory,
    }

    if (editingExpense) {
      if (editingExpense.category === "essential") {
        if (category === "essential") {
          setEssentialExpenses(
            essentialExpenses.map((expense) => (expense.id === editingExpense.id ? newExpense : expense)),
          )
        } else {
          setEssentialExpenses(essentialExpenses.filter((expense) => expense.id !== editingExpense.id))
          setNonEssentialExpenses([...nonEssentialExpenses, newExpense])
        }
      } else {
        if (category === "non-essential") {
          setNonEssentialExpenses(
            nonEssentialExpenses.map((expense) => (expense.id === editingExpense.id ? newExpense : expense)),
          )
        } else {
          setNonEssentialExpenses(nonEssentialExpenses.filter((expense) => expense.id !== editingExpense.id))
          setEssentialExpenses([...essentialExpenses, newExpense])
        }
      }
    } else {
      if (category === "essential") {
        setEssentialExpenses([...essentialExpenses, newExpense])
      } else {
        setNonEssentialExpenses([...nonEssentialExpenses, newExpense])
      }
    }

    handleCloseDialog()
  }

  const handleDeleteExpense = (id: string, category: "essential" | "non-essential") => {
    if (category === "essential") {
      setEssentialExpenses(essentialExpenses.filter((expense) => expense.id !== id))
    } else {
      setNonEssentialExpenses(nonEssentialExpenses.filter((expense) => expense.id !== id))
    }
  }

  const totalEssentialExpenses = calculateTotalExpenses(essentialExpenses)
  const totalNonEssentialExpenses = calculateTotalExpenses(nonEssentialExpenses)
  const totalExpenses = totalEssentialExpenses + totalNonEssentialExpenses

  return (
    <div className="p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Despesas</h1>
        <Button onClick={() => handleOpenDialog()} size="sm">
          <Plus className="mr-2 h-4 w-4" /> Adicionar
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Total de Despesas</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</p>
          <div className="mt-2 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Essenciais</span>
              <span>{formatCurrency(totalEssentialExpenses)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Não Essenciais</span>
              <span>{formatCurrency(totalNonEssentialExpenses)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="essential" onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="essential" className="flex-1">
            Essenciais
          </TabsTrigger>
          <TabsTrigger value="non-essential" className="flex-1">
            Não Essenciais
          </TabsTrigger>
        </TabsList>

        <TabsContent value="essential" className="space-y-2 mt-4">
          {essentialExpenses.map((expense) => (
            <Card key={expense.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">{expense.description}</p>
                    <p className="text-lg font-bold text-red-600">{formatCurrency(expense.amount)}</p>
                    <p className="text-xs text-muted-foreground">{expense.expenseCategory}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(expense)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteExpense(expense.id, "essential")}>
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="non-essential" className="space-y-2 mt-4">
          {nonEssentialExpenses.map((expense) => (
            <Card key={expense.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">{expense.description}</p>
                    <p className="text-lg font-bold text-red-600">{formatCurrency(expense.amount)}</p>
                    <p className="text-xs text-muted-foreground">{expense.expenseCategory}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(expense)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteExpense(expense.id, "non-essential")}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingExpense ? "Editar Despesa" : "Nova Despesa"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium">
                Descrição
              </label>
              <Input
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Aluguel"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="amount" className="text-sm font-medium">
                Valor (R$)
              </label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                step="0.01"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Selecione uma Categoria</label>
              <Select value={expenseCategory} onValueChange={(value) => setExpenseCategory(value as ExpenseCategory)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma Categoria" />
                </SelectTrigger>
                <SelectContent>
                  {expenseCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Tipo de Despesa</label>
              <div className="flex space-x-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="category"
                    checked={category === "essential"}
                    onChange={() => setCategory("essential")}
                    className="h-4 w-4 text-primary"
                  />
                  <span>Essencial</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name="category"
                    checked={category === "non-essential"}
                    onChange={() => setCategory("non-essential")}
                    className="h-4 w-4 text-primary"
                  />
                  <span>Não Essencial</span>
                </label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancelar
            </Button>
            <Button onClick={handleSaveExpense}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

