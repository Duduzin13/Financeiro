import { SignUpForm } from "@/components/auth/sign-up-form"

export default function SignUp() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <SignUpForm />
    </div>
  )
}

